<?php

namespace App\Http\Controllers\Admin\Interfaces;

use Illuminate\Http\Request;

interface ConcernsControllerInterface
{
    //
}
