<?php

namespace App\Http\Controllers\Admin\Interfaces;
use Illuminate\Http\Request;
use App\Http\Requests\RegistrationRequest;
use App\Http\Requests\EditRegistrationeRequest;

interface UsersInformationControllerInterface
{
    //
}