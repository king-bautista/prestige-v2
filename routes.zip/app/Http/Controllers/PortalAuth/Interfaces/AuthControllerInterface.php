<?php

namespace App\Http\Controllers\PortalAuth\Interfaces;
use Illuminate\Http\Request;

interface AuthControllerInterface
{
    
}
