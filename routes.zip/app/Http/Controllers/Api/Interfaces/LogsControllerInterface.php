<?php

namespace App\Http\Controllers\Api\Interfaces;

use Illuminate\Http\Request;

interface LogsControllerInterface
{
    //
}
