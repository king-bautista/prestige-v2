<?php

namespace App\Http\Controllers\AdminAuth\Interfaces;
use Illuminate\Http\Request;

interface AuthControllerInterface
{
    //
}
