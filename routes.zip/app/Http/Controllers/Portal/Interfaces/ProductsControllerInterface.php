<?php

namespace App\Http\Controllers\Portal\Interfaces;
use Illuminate\Http\Request;

interface ProductsControllerInterface
{
    //
}
