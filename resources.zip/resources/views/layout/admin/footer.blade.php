<footer class="main-footer">
    <!-- Default to the left -->
    <strong>Copyright &copy; 2022 <a href="http://www.prestigeinteractive.com.ph/">PRESTIGE INTERACTIVE</a>.</strong> All rights reserved.
</footer>