<template>
  <div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
          <div class="card-body pt-0">
            <div class="ex-page-content text-center">
              <h1 class="text-dark"><i class="nav-icon fas fa-tools"></i>Under Construction</h1>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>